// JavaScript Document

// iMAGE-ANNOTATOR_ITEM
// Full Directory : javascript \ annotator \ workspace \ image-annotator
// Version : 0.1
// Update Date : 2021-03-03-18-37


/* ITEM
 * 1. Image Annotation Item List : 아이템 목록
 * 2.
*/

// Image Annotation Item List : 아이템 목록
class ImageAnnotationItemList {
	
	// 생성자
	// Comment : Data Id 를 초기화합니다.
	construct (data_id) {
		
		// Data Id 를 초기화합니다.
		this.data_id = data_id;
		
		// Item List 를 초기화합니다.
		this.item_list = new List();	
	}
	
	getData_id () {
		return this.data_id;
	}
	
	setData_id (data_id) {
		this.data_id = data_id;
	}
	
	getItem_list () {
		return this.item_list;
	}
	
	setItem_list (item_list) {
		this.item_list = item_list;
	}
}

class ImageAnnotationItem {
	
	construct () {
		this.data_id = "";
		this.class_id = "";
		this.item_id = "";
		this.shapeType_value = "";
		this.shapePointList = new imageAnnotationItemShapePointList();
	}
	
	// Data ID Getter
	getDataId () {
		return this.data_id;
	}
	
	// Data ID Setter
	setDataId (data_id) {
		this.data_id = data_id;
	}
	
	// Class ID Getter
	getClassId () {
		return this.class_id;
	}
	
	// Class ID Setter
	setClassId (class_id) {
		this.class_id = class_id;
	}
	
	// Item ID Getter
	getItemId () {
		return this.item_id;
	}
	
	// Item ID Setter
	setItemId (item_id) {
		this.item_id = item_id;
	}
	
	// Item ID Getter
	getShapeTypeValue () {
		return this.shapeType_value;
	}
	
	// Item ID Setter
	setShapeTypeValue (shapeType_value) {
		this.shapeType_value = shapeType_value;
	}
	
	// Item ID Getter
	getShapePointList () {
		return this.shapePointList;
	}
	
	// Item ID Setter
	setShapePointList (shapePointList) {
		this.shapePointList = shapePointList;
	}
}

class HtmlElement_ImageAnnotation_Item {
	
	create (item_id, shapeType_value) {
		
		// SVG G ELEMENT
		
		// Create
		let element_svg_g = htmlElement.createSVGElement("g");
		
		// Set Svg G Element Attribute
		
		// id, name
		htmlElement.setAttribute(element_svg_g, "id", item_id + "_wire");
		
		// data
		htmlElement.setAttribute(element_svg_g, "data-shpae-type", setAttribute_shpaeType_value(shapeType_value));
		
		// class
		htmlElement.setAttribute(element_svg_g, "class", "annotation--svg-data-item-wire");
		
		// Svg Ploygon Element
		
		// Create 
		let element_sva_polygon = htmlElement.createSVGElement("polygon");
		
		// Set Svg Ploygon Element _ Common Attribute
		
		// id, name
		htmlElement.setAttribute(element_sva_polygon, "id", item_id);
		
		// data
		htmlElement.setAttribute(element_sva_polygon, "data-shpae-type", setAttribute_shpaeType_value(shapeType_value));
		
		// class
		htmlElement.setAttribute(element_sva_polygon, "class", "item polygon-rect polygon-bounding-rect--unselected cursor--cross-cursor");
		
		return 
	}
	
	setAttribute_shpaeType_value (shapeType_value) {
		
		// value 에 box 를 포함하고 있다면
		if (shapeType_value.contains("box")) {
			return "box";
		
		  // value 에 polygon 을 포함하고 있다
		} else if (shapeType_value.contains("polygon")) {
			return "polygon";
		}
	}
	
	addAttribute_shpaeType_class_value (element, shapeType_value) {
		// value 에 box 를 포함하고 있다면
		// (*WORKING POINT)
		if (shapeType_value.contains("box")) {
			return htmlElement.addAttributeValue(element_sva_polygon, "class", );
		
		  // value 에 polygon 을 포함하고 있다
		} else if (shapeType_value.contains("polygon")) {
			return "polygon";
		}
	}
	
	insert (element) {
		return htmlElement.appendChild(workspace_annotation_svg_data_wire, element);
	}
	
	display () {
	}
	
	property () {
	}
	
	hidden () {
	}
	
	delet () {
	}
}
