// JavaScript Document

class Typography {
	
	// 문자열에서 값과 일치하는 문다열의 수를 반환합니다.
	matchString (string, string_value) {
		return string.match(string_value) || []).length;
	}
}