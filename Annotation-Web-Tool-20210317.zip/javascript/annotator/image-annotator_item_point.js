// JavaScript Document

/* POINT
 * 1. Image Annotation Item Shape Point List : 한 아이템의 포인트 목록
 */

// Image Annotation Item Shape Point List : 한 아이템의 포인트 목록
class ImageAnnotationItemShapePointList extends List {
	
	// 생성자
	// Comment : 필수로 Item ID 를 받아 설정합니다.
	constructor (item_id) {
		
		this.item_id_value = item_id;
	}
	
	getItem_id_value () {
		return this.item_id_value;
	}
	
	setItem_id_value (value) {
		this.item_id_value = value;
	}
}

class ImageAnnotationHtmlElementItemShapePointList {
	
	setDocumentElementControllPointXy (element, x, y) {
		element.setAttribute("x", "");
		element.setAttribute("y", "");
	}
	
	// Create-Controll-Point
	createDocumentElementControllPoint () {
		var element = document.createElement("use");
		element.setAttribute("id", "");
		element.setAttribute("class", "");
	}

	// Append-Controll-Point
	appendDocumentElementControllPoint (id) {
		id.appendChild();
	}

	// Dispaly-Controll-Point
	dispalyDocumentElementControllPoint () {

	}

	hideDocumentElementControllPoint () {

	}

	// Delete-Document-Element__Controll-Point
	deleteDocumentElementControllPoint () {

	}
}