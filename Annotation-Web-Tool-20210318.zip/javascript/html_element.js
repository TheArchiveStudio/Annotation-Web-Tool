// JavaScript Document

// HTML ELEMENT
// Comment : HTML 요소.
// Version : 0.11
// Last Update Date : 2021-03-11
// Reference : https://developer.mozilla.org/ko/docs/Web/API/Element

// Element
class HtmlElement {
	
	// Create Element
	// Commnet : 요소를 생성합니다.
	// Replacement Standard Function : document.createElement("");
	createElement (tagName_value) {
		return document.createElement(tagName_value);
	}
	
	// Create SVG Element
	// Commnet : SVG 요소를 생성합니다.
	// Replacement Standard Function : document.createElementNS("http://www.w3.org/2000/svg", tagName_value);
	createSVGElement (tagName_value) {
		return document.createElementNS("http://www.w3.org/2000/svg", tagName_value);
	}
	
	// Create Text Node
	// Commnet : 텍스트 노드를 생성합니다.
	// Replacement Standard Function : document.createTextNode("text_value");
	createTextNode (text_value) {
		return document.createTextNode(text_value);
	}
	
	// Insert Element
	// Commnet : 자식 요소를 추가합니다.
	// Replacement Standard Function : parentNode.appendChild(childNode);
	appendChild (parentNode, childNode) {
		return parentNode.appendChild(childNode);
	}
	
	// Inner HTML
	// Comment : 문자 방식으로 요소를 추가합니다.
	// Replacement Standard Function : parentNode.innerHTML = "html_value";
	innerHTML (parentNode, html_value) {
		return parentNode.innerHTML = html_value;
	}
	
	// Remove Child
	// Commnet : 참조한 자식 요소를 삭제합니다.
	// Replacement Standard Function : parentNode.removeChild(childNode)
	removeChild (parentNode, childNode) {
		return parentNode.removeChild(childNode);
	}
	
	// ATTRIBUTE
	
	// Set Attribute
	// Commnet : 해당 요소에 지정된 이름의 속성과 값을 설정합니다.
	// Replacement Standard Function : element.setAttribute(name_value, value)
	setAttribute (element, name_value, attribute_value) {
		return element.setAttribute(name_value, attribute_value);
	}
	
	// Add Attribute
	// Commnet : 해당 요소에 지정된 이름의 속성에 값을 추가합니다.
	addAttributeValue (element, name_value, attribute_value) {
		
		// 지정된 이름의 Attribute 속성이 있는 경우.
		if (hasAttribute(element, name_value)) {
			
			// 기존 속성 값과 추가할 속성 값의 문자열을 공백을 구분자로하여 합칩니다. (기존의 Attribute 값 + " " + 추가할 Attribute 값)
			return getAttribute(element, name_value) + " " + attribute_value; 
			
		// 지정된 이름의 Attribute 속성이 없는 경우.
		} else {
			
			// 새로운 Attribute 속성과 값을 설정합니다./
			return setAttribute(element, name_value, attribute_value);
		}
	}
	
	// Get Attribute 
	// Comment : 해당 요소에 지정된 이름의 속성에 값을 반환 합니다. 만약 주어진 속성이 존재 하지 않는 다면, null 값 혹은 ""(빈문자열) 값을 반환 할 것입니다.
	// Replacement Standard Function : element.getAttribute(name_value)
	getAttribute (element, name_value) {
		return element.getAttribute(name_value);
	}
	
	// Has Attribute
	// Commnet : 해당 요소에 지정된 이름의 속성이 존재하는지 확인합니다.
	// Replacement Standard Function : element.hasAttribute(name_value)
	hasAttribute (element, name_value) {
		return element.hasAttribute(name_value);
	}
	
	// Has Attribute Value
	// Commnet : 해당 요소에 지정된 이름의 속성의 속성값과 일치하는 문자열이 1개 인지 확인합니다.
	// Replacement Standard Function : element.hasAttribute(name_value)
	hasAttributeValue (element, name_value, attribute_value) {
		
		// 이름의 Attribute 속성이 있을 경우.
		if (hasAttribute(element, name_value)){
			
			// 속성값과 일치하는 문자열이 1개 인 경우.
			if ((typography.matchString(getAttribute(element, name_value), attribute_value)) == 1) {
				return true;
				
			  // 속성값과 일치하는 문자열이 1개 미만이거나 2개 이상인 경우.
			} else {
				return false;
			}
			
		  // 이름의 Attribute 속성이 없을 경우.
		} else {
			return false;
		}
	}
	
	// Has Attribute Values
	// Commnet : 해당 요소에 지정된 이름의 속성의 속성값과 일치하는 문자열이 1개 이상인지 확인합니다.
	// Replacement Standard Function : element.hasAttribute(name_value)
	hasAttributeValues (element, name_value, attribute_value) {
		
		// 이름의 Attribute 속성이 있을 경우.
		if (hasAttribute(element, name_value)){
			
			// 속성값과 일치하는 문자열이 1개 이상인 경우.
			if ((typography.matchString(getAttribute(element, name_value), attribute_value)) >= 1) {
				return true;
				
			  // 속성값과 일치하는 문자열이 1개 미만인 경우.
			} else {
				return false;
			}
			
		  // 이름의 Attribute 속성이 없을 경우
		} else {
			return false;
		}
	}
	
	// Remove Attribute
	// Commnet : 해당 요소에 지정된 이름의 속성을 삭제합니다.
	// Replacement Standard Function : element.removeAttribute(name_value)
	removeAttribute (element, name_value) {
		return element.removeAttribute(name_value);
	}
	
	// Delete Attribute Value
	// Commnet : 해당 요소에 지정된 이름의 속성된 지정된 값이 1개인 경우 해당 값을 삭제합니다.
	deleteAttributeValue (element, name_value, includes_value) {
		
		// 해당 요소에 지정된 이름의 속성의 속성값과 일치하는 문자열이 1개 인지 확인합니다.
		if (hasAttributeValue(element, name_value, includes_value)){
			
			let attribute_value = getAttribute(element, name_value);
				
			// 앞 구분자 유무 (*WROKING POINT)
			if (attribute_value.search(" " + includes_value)) {
				return setAttribute(element, name_value, (attribute_value.replce(" " + includes_value, ""));

			  // 뒤 구분자 유무
			} else if (attribute_value.search(includes_value + " ")) {
				return attribute_value.replce(includes_value + " ", "");

			  // 앞뒤 구분자 없음
			} else {
				return attribute_value.replce(includes_value, "");
			}
		}
	}
	
	// Delete Attribute Values
	// Commnet : 해당 요소에 지정된 이름의 속성된 지정된 값을 삭제합니다.
	deleteAttributeValues (element, name_value, includes_value) {
		
		// name_value 이름의 Attribute 속성이 존재 유무
		if (hasAttributeValues(element, name_value, includes_value)){
			
			let attribute_value = getAttribute(element, name_value);
			
			// 앞 구분자 유무
			if (attribute_value.search(" " + includes_value)) {
				return attribute_value.replce(" " + includes_value, "");
			} 
			
			// 뒤 구분자 유무
			if (attribute_value.search(includes_value + " ")) {
				return attribute_value.replce(includes_value + " ", "");
			}
			
			// 앞뒤 구분자 없음
			return attribute_value.replce(includes_value, "");
		}
	}
}

// (*Undefined) Node
class HtmlElementNode {
	
	constructor (element) {
		
		// Element 요소
		this.element = element;
		// Parent Node : 부모 노드.
		this.parentNode;
		// 앞 부모 노드
		this.frontParentNode;
		// 뒤 부모 노드
		this.backParentNode;
		// Sibling Node List : 형제 노드 목록
		this.siblingNodeList;
		// 앞 형제 노드
		this.frontSiblingNode;
		// 뒤 형제 노드
		this.backSiblingNode;
		// 첫번째 형제 노드.
		this.firstSiblingNode;
		// 마지막 형제 노드.
		this.lastSiblingNode; 
		// Degree 차수 : 자식 노드의 수. ( 0 : leafNode 자식이 없는 노드. / 0^ : branchNode 자식이 있는 노드. )
		this.degree_value;
		// Child Node 자식 노드 목록.
		this.childNodeList;
	}	
}

// Attribute
class HtmlElementAttribute {
	
	
}

// CSS (Cascading Style Sheets)
class HtmlStyle {
	
	// Display Element
	// Commnet : 지정된 요소를 문서에 표기합니다.
	display (element) {
		element.style.display = element.getAttribute(display) || "";
	}
	
	// Hidden Element
	// Commnet : 지정된 요소를 문서에 표기하지 않습니다. (기존 style의 display 속성 값을 display 이름의 Attribute 값으로 저장합니다.)
	hidden (element) {
		element.setAttribute("display", element.style.display);
		element.style.display = "hidden";
	}
}