// JavaScript Document

class Typography {
	
	// 문자열에서 값과 일치하는 문다열의 수를 반환합니다.
	matchString (string, includes_value) {
		return (string.match(includes_value) || []).length;
	}
	
	isIncludesString (string, includes_value) {
		return string.includes(includes_value);
	}
}